from django.contrib import admin
from .models import sindhi,northeast,malayalam,contact,language,literary_work
# Register your models here.
admin.site.register(sindhi)
admin.site.register(northeast)
admin.site.register(malayalam)
admin.site.register(contact)
admin.site.register(language)
admin.site.register(literary_work)